open Bindlib
open Ast

type 'a error = OK of 'a | Error of string

module Ctx = Map.Make(String)

let rec synthesize : texpr Ctx.t -> term -> texpr error = fun gamma m ->
  failwith "not_implemented"
and check : texpr Ctx.t -> term -> texpr -> texpr error = fun gamma m sigma ->
  failwith "not_implemented"

let tc : term -> texpr error = synthesize Ctx.empty
